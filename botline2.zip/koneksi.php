<?php
	$conn = mysqli_connect();
?>